//@ui5-bundle app/mylibrary/library-preload.js
/*!
 * ${copyright}
 */
sap.ui.predefine("app/mylibrary/Example",["./library","sap/ui/core/Control","./ExampleRenderer"],function(e,r,a){"use strict";var p=e.ExampleColor;var l=r.extend("app.mylibrary.Example",{metadata:{library:"app.mylibrary",properties:{text:{type:"string",group:"Data",defaultValue:null},color:{type:"app.mylibrary.ExampleColor",group:"Appearance",defaultValue:p.Default}},events:{press:{}}},renderer:a,onclick:function(){this.firePress()}});return l});
/*!
 * ${copyright}
 */
sap.ui.predefine("app/mylibrary/ExampleRenderer",["sap/ui/core/Core","./library"],function(e,r){"use strict";var i=r.ExampleColor;var t={apiVersion:2};t.render=function(e,r){e.openStart("button",r);if(r.getColor()===i.Highlight){e.class("myLibPrefixExampleHighlight")}else{e.class("myLibPrefixExample")}e.openEnd();e.text(r.getText());e.close("button")};return t});
/*!
 * ${copyright}
 */
sap.ui.predefine("app/mylibrary/library",["sap/ui/core/library"],function(){"use strict";sap.ui.getCore().initLibrary({name:"app.mylibrary",version:"1.0.0",dependencies:["sap.ui.core"],types:["app.mylibrary.ExampleColor"],interfaces:[],controls:["app.mylibrary.Example"],elements:[],noLibraryCSS:false});var r=app.mylibrary;r.ExampleColor={Default:"Default",Highlight:"Highlight"};return r});
jQuery.sap.registerPreloadedModules({
"version":"2.0",
"modules":{
	"app/mylibrary/manifest.json":'{"_version":"1.12.0","sap.app":{"id":"app.mylibrary","type":"library","applicationVersion":{"version":"1.0.0"},"title":"Demo Lib","description":"Demo Lib","ach":"","offline":true},"sap.cloud":{"public":true,"service":"app.mylibrary"},"sap.ui":{"technology":"UI5","icons":{"icon":"","favIcon":"","phone":"","phone@2":"","tablet":"","tablet@2":""},"deviceTypes":{"desktop":true,"tablet":true,"phone":true}},"sap.ui5":{"dependencies":{"minUI5Version":"1.52.0","libs":{"sap.ui.core":{"minUI5Version":"1.52.0"}}},"library":{"i18n":"messagebundle.properties","css":true,"content":{"controls":["app.mylibrary.Example"],"elements":[],"types":[],"interfaces":[]}}}}'
}});
