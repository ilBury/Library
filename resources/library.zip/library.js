/*!
 * ${copyright}
 */
sap.ui.define(["sap/ui/core/library"],function(){"use strict";sap.ui.getCore().initLibrary({name:"app.mylibrary",version:"1.0.0",dependencies:["sap.ui.core"],types:["app.mylibrary.ExampleColor"],interfaces:[],controls:["app.mylibrary.Example"],elements:[],noLibraryCSS:false});var e=app.mylibrary;e.ExampleColor={Default:"Default",Highlight:"Highlight"};return e});