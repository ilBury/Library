/*!
 * ${copyright}
 */
sap.ui.define(["sap/ui/core/Core","./library"],function(e,i){"use strict";var t=i.ExampleColor;var r={apiVersion:2};r.render=function(e,i){e.openStart("button",i);if(i.getColor()===t.Highlight){e.class("myLibPrefixExampleHighlight")}else{e.class("myLibPrefixExample")}e.openEnd();e.text(i.getText());e.close("button")};return r});